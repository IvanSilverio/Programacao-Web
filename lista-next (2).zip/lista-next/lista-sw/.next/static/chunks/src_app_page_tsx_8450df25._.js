(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_c77ddcec._.css",
  "static/chunks/node_modules_0b26cab6._.js",
  "static/chunks/src_app_ui_9cb97313._.js"
],
    source: "dynamic"
});
