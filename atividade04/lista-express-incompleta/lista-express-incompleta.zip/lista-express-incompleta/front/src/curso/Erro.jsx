import '../styles/Erro.css';
export default function Erro({msg}){

    return (
        <p>{msg}</p>
    );
}