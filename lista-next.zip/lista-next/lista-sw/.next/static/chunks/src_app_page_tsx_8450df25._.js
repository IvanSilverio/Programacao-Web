(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0b26cab6._.js",
  "static/chunks/src_app_ui_7d069692._.js"
],
    source: "dynamic"
});
