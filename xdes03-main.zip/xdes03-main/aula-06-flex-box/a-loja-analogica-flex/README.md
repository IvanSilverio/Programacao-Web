# Aula-6-Flex-box

Exemplo utilizado na disciplina XDES03 para praticar flex-box.

Projeto: A Loja Analógica

![A Loja Analógico](figuras/loja-analogica-front.png)
