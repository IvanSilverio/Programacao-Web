import CreateUserForm from "@/app/ui/form-create";


export default function Create() {
  return(
    <CreateUserForm />
  );
}