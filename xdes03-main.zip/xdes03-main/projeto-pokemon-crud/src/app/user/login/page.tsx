
import LoginForm from "@/app/ui/form-login";

export default function Login(){
    return(
        <LoginForm />
    );
}