import { useState } from 'react'
import './App.css'
import Pokemons from './Pokemons'

function App() {
  
  return (
    <>
      <Pokemons />
    </>
  )
}

export default App
