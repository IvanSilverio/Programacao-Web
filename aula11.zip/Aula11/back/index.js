//import express from 'express';
const express = require('express');
const fs = require('fs');
const path = require('path');

//caminho para o banco de dados
const dbPath = path.join('db', 'disciplinas.json');

const app = express();
//manipular o arquivo

app.get('/login', (req, res) => {    

    //const nome = req.query.nome;
    //const senha = req.query.senha;

    //const msg = `Olá ${nome} sua senha é ${senha}`;

    //Conectar ao banco de dados
    const disciplinasDBString = fs.readFileSync(dbPath, {encoding : 'utf-8'});
    const disciplinas = JSON.parse(disciplinasDBString)
    res.send(disciplinas);
});

app.listen(3000, () => {
    console.log('Servidor ligado no 3000...');
});