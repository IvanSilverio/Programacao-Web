const parametros = process.argv.slice(2);

console.log(parametros);